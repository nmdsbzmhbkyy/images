# 学习建议

以下是一些建议，帮助你更快地接触Go语言的实战项目：

1. **深入了解Go语言基础**：
   - 确保你对Go的基础语法、数据类型、控制流等有一定的了解。可以通过阅读相关文档、教程或参与在线课程来学习。
2. **实践项目**：
   - 尝试构建一些小型的项目，这可以帮助你更深入地理解Go的并发模型和语法特性。
   - 选择一些与你之前经验相关的项目，例如Web服务、API开发等，以便更容易将已有知识与新学到的Go知识结合起来。
3. **阅读实际项目的源代码**：
   - 在GitHub等代码托管平台上找到一些使用Go语言编写的开源项目，并阅读它们的源代码。这有助于你学习Go语言的最佳实践和常见的项目结构。
4. **学习Go的并发模型**：
   - 由于资料已经介绍了Go的并发基础，尝试在实际项目中应用这些知识。构建一个简单的并发应用程序，例如使用goroutines和channels解决实际问题。
5. **参与社区和讨论**：
   - 加入Go语言的社区，参与讨论、提问问题，并与其他开发者交流经验。这有助于你更快地解决问题，获取实际应用的建议。学习一些设计模式。
6. **尝试与现有技术栈集成**：
   - 如果可能，尝试将Go与你已经掌握的技术栈集成，例如使用Go开发微服务，并与Spring Cloud等进行交互。这有助于你将Go融入到实际项目中。
7. **学习测试和性能优化**：
   - 学习如何编写有效的测试，并了解Go语言的性能优化技巧。这对于构建高性能的应用程序至关重要。
8. **持续学习和更新**：
   - Go语言的生态系统不断发展，保持学习的状态很重要。关注Go语言的新特性、库和最佳实践。

最重要的是，将学到的知识应用到实际项目中，并持续改进你的Go编程技能。通过不断地编写代码和解决实际问题，你将更快地适应并掌握这门新的编程语言。

# 前言

## go环境搭建

1. go开发工具——goland的下载与激活:
   1. goland激活方式：[Goland 2022.3 破解教程 有效专属激活码注册码 永久激活教程 长期更新 | ide激活网 (idejihuo.com)](https://blog.idejihuo.com/jetbrains/goland-2022-3-crack-tutorial-effective-exclusive-activation-code-registration-code.html)
2. go环境(SDK)下载与配置：

   1. go环境搭建要干什么：[Go学习第一章——开发环境安装以及快速入门（GoLand）_goland创建go项目-CSDN博客](https://blog.csdn.net/Hai_Helloyou/article/details/133936561)
   1. SDK的配置：[Windows上安装 Go 环境并配置环境变量 （超详细教程）_go环境变量配置 windows_A-刘晨阳的博客-CSDN博客](https://blog.csdn.net/liu_chen_yang/article/details/132012969)

3. QuickStart：
   1. 测试是否能正常使用goland：GoLand 快速入门教程-CSDN博客](https://blog.csdn.net/K346K346/article/details/105554216)
4. 补充：
   1. [Windows下搭建Go开发环境——安装和配置SDK_chengqiuming的博客-CSDN博客](https://blog.csdn.net/chengqiuming/article/details/115380503)
   2. [(2 封私信 / 16 条消息) Go语言有什么好用的IDE吗？ - 知乎 (zhihu.com)](https://www.zhihu.com/question/25012617)

## 文件位置记录：

1. IDE位置：D:\Program Files\JetBrains\GoLand 2022.3.4
2. SDK位置：D:\Program Files\Go

# 资料：

1. 别人的go学习笔记：[XiaoZhi-paperfly_算法,数据结构-CSDN博客](https://blog.csdn.net/Hai_Helloyou?type=blog)
1. 论坛笔记：[《Go 入门指南》 | Go 技术论坛 (learnku.com)](https://learnku.com/docs/the-way-to-go)
1. RPC是什么：[RPC是什么，看完你就知道了 - 知乎 (zhihu.com)](https://zhuanlan.zhihu.com/p/187560185)

# Go语言结构

当标识符（包括常量、变量、类型、函数名、结构字段等等）以一个大写字母开头，如：Group1，那么使用这种形式的标识符的对象就可以被外部包的代码所使用（客户端程序需要先导入这个包），这被称为导出（像面向对象语言中的 public）；标识符如果以小写字母开头，则对包外是不可见的，但是他们在整个包的内部是可见并且可用的（像面向对象语言中的 protected ）。

# 补充：

GOPATH和GOROOT的简单介绍：

- 一个是 GOROOT ，这个就是 Go 环境所在目录的配置。
- 另一个是 GOPATH ，这个是 Go 项目的工作目录，你以后开发的代码就写在这个文件夹中。
- GOPATH和GOROOT的配置略有不同，我建议配置两个GOPATH目录，第一个用于放 Go 语言的第三方包，第二个用于放自己的开发代码。我们来新建GOPATH。点击系统变量下的新建，在变量名一栏输入GOPATH，在变量值一栏输入任意两个目录，中间用英文分号隔开。

[LiteIDE 的下载、安装、配置及项目调试 - 测试开发喵 - 博客园 (cnblogs.com)](https://www.cnblogs.com/l199616j/p/14230682.html)

