[使用Git上传项目到GitHub](https://blog.csdn.net/qq_43142509/article/details/123134869)
[将Java对象转换成JSON](https://blog.csdn.net/jinxlzc/article/details/89361208)

[fanqianglu.com](https://fanqianglu.com/free/cntube)

我们学编程的，学的是思想，而不是会调用几个东西就能进大厂

[伙伴匹配项目笔记 | 烤猫blog (chenkai.fun)](https://myblog.chenkai.fun/article/friends-matching-notes)

关于如何做项目，重视的也是思想，实现起来的话，都是比较简单的，不必过于纠结实际实现代码的时候。

### 项目

#### 伙伴匹配

后端和前段的对接是用get还是用post：查看数据的话，就用get就好了，添加修改就用post

[伙伴匹配笔记.md](file://E:/学习/项目/笔记/伙伴匹配笔记.md)

[android 客户端和服务端cookie,如何在Android客户端注入及清除Cookie教程_道路Master-华为云开发者联盟 (csdn.net)](https://huaweicloud.csdn.net/6507db3b4cd6367bad134634.html?dp_token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpZCI6MjYwNTM1MiwiZXhwIjoxNjk2OTgxMDIxLCJpYXQiOjE2OTYzNzYyMjEsInVzZXJuYW1lIjoid2VpeGluXzU5NTA0Nzk2In0.CaA9LzEykO4PoynAWXp8TDleAqeUgS6Aa7XbuDdXIFs)

##### 更新数据库数据补充:

1. [使用Mybatis-plus内置方法,更新一个字段还是全部字段，三种应对情况下性能效率比较_basemapper 更新一个字段-CSDN博客](https://blog.csdn.net/qq_27037397/article/details/115540564)
2. 根据情况来决定怎么样更新数据的函数是什么,并且要先决定函数是什么,不过大不了就是后面再改就是了.

##### 加快操作数据库速度即操作分页数据库

1. [mybatis plus 限制查询个数_mybatisplus limit-CSDN博客](https://blog.csdn.net/weixin_39802680/article/details/114545124)
2. [mysql limit分页（偏移量）过大时优化问题_limit后面的范围非常大-CSDN博客](https://blog.csdn.net/qq_39404258/article/details/106333205)

##### 模型类

1. [DAO和DTO的区别_dto和dao-CSDN博客](https://blog.csdn.net/zcywell/article/details/7204186)
2. [【Java】一图看懂Java中的PO,BO,VO,DTO,POJO,DAO,DO - 掘金 (juejin.cn)](https://juejin.cn/post/6952848675924082718)

##### mybatis-X的插件使用

跨域前端设置:[Vue3使用vite配置前端服务IP、端口、跨域代理、访问资源路径前缀_郭新宇2020的博客-CSDN博客](https://blog.csdn.net/qq_36293096/article/details/118364950)

##### 修改项目/个人化配置:

1. 重命名项目：[IntelliJ IDEA怎么对项目重命名_lntellijidea构建的文件名怎么更改_海森堡·古德曼的博客-CSDN博客](https://blog.csdn.net/Real_zzQ/article/details/112254667)
2. pom文件变红：[IDEA中pom.xml文件图标变红，而不是蓝问题_pom.xml不是蓝色_需求两年半的蜀俞的博客-CSDN博客](https://blog.csdn.net/ZYR2000450/article/details/126448769)
3. 缺少iml文件：[idea 缺少.iml 文件或删掉.iml文件刷新maven无法恢复解决_idea删除imi_㗊㗊的博客-CSDN博客](https://blog.csdn.net/selest/article/details/106493509)
4. 当有`不正确引入、5、yaml里的相关配置没配置好时和6、bean作用范围为web应用时`的报错：[java.lang.IllegalStateException: Failed to load ApplicationContext 解决办法_，稳步前进的博客-CSDN博客](https://blog.csdn.net/qq_42815122/article/details/85395111)
5. mapper引入问题：[大叔学Spring Boot笔记（14）A component required a bean of type '...Mapper' that could not be found问题解决 - 无敌师爷IT技术Blog - 博客园 (cnblogs.com)](https://www.cnblogs.com/61007257Steven/p/13229456.html)
6. [@Scope注解的作用详解_TzBugs的博客-CSDN博客](https://blog.csdn.net/tzbugs/article/details/82142286)，另外，可参考[SpringBoot原理篇.md](file://E:\学习\SSM_JavaWeb开发学习\资料\day14-SpringBoot原理篇\讲义\SpringBoot原理篇.md)
7. [HTTP请求中如何选择Get和Post方式_浏览器端可以选择用post或get吗_IT_驿站的博客-CSDN博客](https://blog.csdn.net/u012560902/article/details/52159543)

##### 筛选数组数据:

```javascript
let tempParentTag = JSON.parse(JSON.stringify(taglist))
```

[JavaScript对象拷贝遇到的坑和解决方法 - 知乎 (zhihu.com)](https://zhuanlan.zhihu.com/p/33752259)

补充:lamdal表达式的代码块里一有一行,可以用中括号,花括号,或无括号.

##### 前端dom元素滑动跳转:

```javascript
let tags =  document.querySelectorAll('.van-tree-select__item')
console.log(tags)
tags.forEach(tag => {
    if (tag.innerText === searchValue.value){
        console.log(tag)
        tag.scrollIntoView()
    }
})
```

1. [学习JavaScript这一篇就够了_javascript学这一篇就够了_轻松的小希的博客-CSDN博客](https://blog.csdn.net/qq_38490457/article/details/109257751?spm=1001.2014.3001.5506)
2. [获取DOM元素后，对NodeList的遍历的几种方法_nodelist 遍历_CAICANY的博客-CSDN博客](https://blog.csdn.net/chenlincc/article/details/107531420)
3. router自定义路由导出多个：[TypeScript 中的 export 和 import-腾讯云开发者社区-腾讯云 (tencent.com)](https://cloud.tencent.com/developer/article/1676715)

##### 后端controller

[java 传参 非必填_处理@PathVariable注解允许参数为空、允许不传参数的问题_月饼AllenZ的博客-CSDN博客](https://blog.csdn.net/weixin_35042833/article/details/114727418)

##### vant组件找不到问题:

[Vite + Vue3 +Vant4构建项目时，按需引入使用Toast组件，引用 showToast 时出现编译报错的解决方案-CSDN博客](https://blog.csdn.net/m0_52459016/article/details/128967074)

##### vue scopt覆盖组件样式

[Vue scoped与覆盖第三方组件样式_vue 覆盖 scope样式-CSDN博客](https://blog.csdn.net/qq_37176126/article/details/94405841)

##### 前端遍历数组元素:

[Vue前端js循环遍历数组八种方法总结最新_vue循环遍历数组对象_MFG_666的博客-CSDN博客](https://blog.csdn.net/m0_49714202/article/details/122689179)

##### 后端mybatisx插件传产生代码介绍:

[MybatisX-Generator代码生成详解-CSDN博客](https://blog.csdn.net/Ying_ph/article/details/121972700)

##### 服务器接收时间参数问题:

1. [vue中字符串和Date格式相互转换_vue字符串转date-CSDN博客](https://blog.csdn.net/weixin_43120343/article/details/106682417)
2. [不要在听大坑们@DateTimeFormat 和 @JsonFormat只是前后端传参的区别了_java @jsonformat 是接收前端参数吗-CSDN博客](https://blog.csdn.net/a1035434631/article/details/109740122)
3. [5分钟了解GMT，CST，UTC是什么鬼？ - 腾讯云开发者社区-腾讯云 (tencent.com)](https://cloud.tencent.com/developer/news/296916)
4. [实体类日期时间入参@DateTimeFormat 和出参@JsonFormat 格式化_实体类接受一个时间参数-CSDN博客](https://blog.csdn.net/liaomingwu/article/details/107077041)
5. [Spring连接Mysql获取数据时间快8小时或慢8小时时区问题_mysql快了8小时_ArtemisKhryso的博客-CSDN博客](https://blog.csdn.net/ArtemisKhryso/article/details/121566595)
6. [MybatisX-Generator代码生成详解-CSDN博客](https://blog.csdn.net/Ying_ph/article/details/121972700)

#### 使用通义千问API

[java调用阿里通义千问.md](file://D:\system-moren\java调用阿里通义千问.md)

[完美解决 java: 无效的目标发行版: 11_无效的目标发行版11_JavaGPT的博客-CSDN博客](https://blog.csdn.net/weixin_46294086/article/details/124203970)还需要配置project的jdk

[Java编程基础 (wolai.com)](https://www.wolai.com/v4Ys3B8k8ZvswuBzgrbX7g)jdk和jre的区别

#### 内网穿透的应用

[‪内网穿透的应用.md](file://E:\学习\积累笔记\内网穿透的应用.md)

### 部署上线:

> 多环境的配置
>
> 部署有多种方式部署
>
> 上线就是配置域名以及跨域问题的处理

**参考链接：**

1. [WebStorm中如何将自己的代码上传到github_webstorm提交代码到github-CSDN博客](https://blog.csdn.net/qq_42114171/article/details/109300452?ops_request_misc=%7B%22request%5Fid%22%3A%22169644655416800192258676%22%2C%22scm%22%3A%2220140713.130102334.pc%5Fall.%22%7D&request_id=169644655416800192258676&biz_id=0&utm_medium=distribute.pc_search_result.none-task-blog-2~all~first_rank_ecpm_v1~times_rank-8-109300452-null-null.142^v94^insert_down28v1&utm_term=webstorm提交代码到github&spm=1018.2226.3001.4187)，我这里设置新分支main，删除旧分支，然后commit&push，然后莫名其妙的就成功了，反正主要看缘分吧，缘分到了就可以上传成功吧应该。
2. [使用 Vercel 快速部署前端项目 - 知乎 (zhihu.com)](https://zhuanlan.zhihu.com/p/578452272)
3. [1分钟上线个人网站？这个工具杀疯了！_哔哩哔哩_bilibili](https://www.bilibili.com/video/BV1TV4y1j76t/?vd_source=b6865a5e968b98ea450a39e00ef7e85d)

**vercel部署遇到的问题及处理方式:**

1. vue-tsc无法跳过对node_modules内部的文件校验问题：[Vue3 vite：is a JavaScript file. Did you mean to enable the 'allowJs' option? - 掘金 (juejin.cn)](https://juejin.cn/post/7091544102021857288)
2. 国内无法访问问题：
   1. [解决 Vercel 在国内无法访问 | 随风 (adunm.top)](https://adunm.top/posts/4a17b151/)（也还有其他办法，比如通过cloudflare管理vercel域名，以及使用cname-china.vercel-dns.com这个CNAME域名，这两种我试着都没法用，不知道为什么，成功过的只有设置76.223.126.88这个A记录，但是第二天就又不行了）
3. 又拍云是什么?加速的是什么?CDN的理解:
   1. [计算机网络——CDN加速技术原理_cdn加速原理_庄小焱的博客-CSDN博客](https://zhuangxiaoyan.blog.csdn.net/article/details/125762666?spm=1001.2101.3001.6650.8&utm_medium=distribute.pc_relevant.none-task-blog-2~default~BlogCommendFromBaidu~Rate-8-125762666-blog-100726481.235^v38^pc_relevant_sort_base1&depth_1-utm_source=distribute.pc_relevant.none-task-blog-2~default~BlogCommendFromBaidu~Rate-8-125762666-blog-100726481.235^v38^pc_relevant_sort_base1&utm_relevant_index=11)
   2. [博客配置又拍云CDN - MelodyJerry - 博客园 (cnblogs.com)](https://www.cnblogs.com/melodyjerry/p/14382866.html)

**其他：**

直接网络连接：

1. 报错：net::ERR_CONNECTION_CLOSED，用谷歌手机连前端都加载不出来，edge可以加载，但是后端也加载不了（大概率是因为访问后端频繁导致的无法访问后端），谷歌可以加载后端，所以可能是edge残留的信息，删了后，前段也访问不了了。后端是都可以访问的了了。
2. 所以就猜是不是地址解析的问题？

**补充链接：**

1. [DNS测（DNSCE.COM）：域名被污染，就选DNS测！域名污染,DNS污染,域名加速,DNS加速,免费域名检测](https://dnsce.com/)
2. [站长工具ping检查](https://ping.chinaz.com)
3. [vercel官网](https://vercel.com/)
4. [什么是DNS污染? - 知乎 (zhihu.com)](https://zhuanlan.zhihu.com/p/651371484)
6. [地理定位 IP 地址的位置 | 地理定位 (geolocation.com)](https://www.geolocation.com/zh_cn?ip=99.83.91.178#ipresult)
7. 什么是vpn

```java
//user
vpn的原理，为什么可以访问外网无法访问的地址
//ChatGPT
虚拟私人网络（VPN）是一种用于创建安全的、加密的网络连接的技术，允许用户通过公共网络（通常是互联网）访问外部网络资源，同时隐藏其真实的IP地址。VPN的原理如下：

加密通信： 当你连接到VPN服务器时，所有的网络通信都被加密。这意味着你的数据在传输过程中被加密，使其更难以被截获或窃取。

IP地址隐藏： VPN服务器充当中间人，将你的请求发送到目标网站，然后将响应返回给你。这意味着目标网站只会看到VPN服务器的IP地址，而不是你的真实IP地址，从而保护了你的隐私。

隧道技术： VPN使用隧道技术将你的数据从本地设备传输到VPN服务器，然后再传输到目标服务器。这种隧道化的通信保护了数据免受外部干扰，并确保数据的完整性。

至于为什么VPN可以访问外网无法访问的地址，这与VPN服务器的位置和配置有关：

服务器位置： VPN服务提供商通常在不同的地理位置部署多个服务器。当你连接到VPN时，你可以选择连接到不同地区的服务器。如果某个特定的网站或服务在你的当前位置被封锁或受限，你可以通过连接到位于其他地区的VPN服务器来绕过这些限制。

IP地址变更： 当你连接到VPN服务器时，你的IP地址会变成VPN服务器的IP地址。如果某些网站或服务只允许特定IP地址范围的访问，通过连接到VPN，你可以获得不同的IP地址，从而绕过这些限制。

需要注意的是，使用VPN绕过地理位置限制或访问被封锁的内容可能违反某些网站或服务的使用政策，也可能违反法律。因此，在使用VPN时，你应该了解相关法规和服务政策，并谨慎使用。
```



### 内网穿透

1. [内网穿透详解 - cyrus0w - 博客园 (cnblogs.com)](https://www.cnblogs.com/cyrus0w/p/13123504.html)
2. [内网穿透（NAT 穿透）原理+工具（部分无需管理员权限）_nat工具_noobiee的博客-CSDN博客](https://blog.csdn.net/m0_64768308/article/details/131283212#:~:text=实现内网穿透 是为了使具有某一个特定源 IP 地址和源端口号的数据包不被,NAT 设备屏蔽而正确路由到内网主机（因为NAT设备自动屏蔽了非内网主机主动发起的连接，从而保护外部网络的攻击但也为P2P通信带来困难）。 内网穿透的原理 ：NAT设备（或软件）维护一个状态表，用来把内部网络的私有IP地址映射到外部网络的合法IP地址上去。 每个包头中的IP地址和端口信息在NAT设备（或软件）中都被修改并翻译成一正确的IP地址发往下一级。)
3. [内网穿透你真的了解吗？ - 知乎 (zhihu.com)](https://zhuanlan.zhihu.com/p/594928131)
4. dns解析域名以及内网穿透域名的关系，对其他地址的项目影响：[计算机网络第5章（运输层） - 简书 (jianshu.com)](https://www.jianshu.com/p/ff5c1089a985)

 * ChatGPT关于域名及会话的回答:

```java
User
// a.com和b.a.com是同一个域名么
ChatGPT
/*
不完全相同。域名a.com和b.a.com具有不同的子域（subdomains）。

a.com是一个顶级域名（Top-Level Domain，TLD），通常用于表示网站的主要部分。
b.a.com是一个子域名，它是a.com的一个子域。通常，子域用于将不同部分的网站或服务分隔开，或者用于组织网站的内容。
实际上，b.a.com表示在a.com域名下创建的一个子网站或子服务。这两个域名在层次结构上不同，但它们都归属于.com顶级域。
*/

User
// 不同浏览器访问同一服务是不同会话么
ChatGPT
/*
不同浏览器访问同一服务通常被视为不同会话。会话是一种在用户与服务器之间建立的状态，用于跟踪用户与服务的交互。每个浏览器都会为用户创建一个单独的会话，因此不同浏览器之间的会话是分离的，它们不会共享相同的会话状态。

这意味着如果您使用不同的浏览器（例如Chrome、Firefox、Safari等）访问同一服务，服务器通常会将它们视为不同的用户或会话。这可以确保用户在不同浏览器中的操作不会相互干扰，各自拥有各自的会话状态、登录状态、购物车内容等。

然而，请注意，某些网站可能会提供跨浏览器同步功能，允许用户在不同浏览器之间共享某些数据，但这通常需要用户明确的设置或登录到其账户，并不是默认行为。默认情况下，不同浏览器之间的会话是独立的。
*/
    
User
//同一浏览器访问同一服务就是同一个会话么，那打开多个同一浏览器的情况下呢
ChatGPT
/*
在同一浏览器中访问同一服务通常会被视为同一个会话，因为浏览器会在单个窗口或标签页中共享会话状态和会话数据。这意味着，如果您在同一浏览器的不同标签页中打开同一服务，这些标签页将共享相同的会话信息，包括登录状态、会话令牌、会话cookie等。这使得用户可以在不同标签页之间无缝切换，而不必重复登录或重新输入数据。

然而，如果您在同一浏览器中打开多个不同浏览器窗口（例如，使用两个独立的浏览器窗口，而不是标签页），通常情况下，这些窗口将被视为不同的会话，它们之间不会共享会话状态。这是因为每个浏览器窗口通常都有自己的会话上下文。

总之，在同一浏览器的标签页中访问同一服务会被视为同一个会话，但在不同浏览器窗口中访问同一服务通常会被视为不同的会话。这些规则可能因浏览器的具体实现和设置而有所不同，但这是一般情况。
*/
```

### 改进进程运行效率

#### 原生代码创建进程方法

[java线程池使用详解ThreadPoolExecutor使用示例_threadpoolexecutor使用案例_老鼠小哥的博客-CSDN博客](https://blog.csdn.net/xu_yong_lin/article/details/117521773)

#### Redis分布式锁

[【Redis】redis主从不一致问题(redis缺点、缺陷)_云川之下的博客-CSDN博客](https://blog.csdn.net/m0_45406092/article/details/117175920)

[Redisson-红锁(Redlock)-使用/原理 - 自学精灵 (skyofit.com)](https://learn.skyofit.com/archives/1338)

### 自定义SDK

#### 不同自动注入的理解

1. [@Resource和@Autowired的区别，小白看完这篇你就懂了 - 知乎 (zhihu.com)](https://zhuanlan.zhihu.com/p/265982399)
2. [面试官：@Resource和@Autowired有啥区别？-腾讯云开发者社区-腾讯云 (tencent.com)](https://cloud.tencent.com/developer/article/1815253)
3. [@Autowired注解是否需要setter方法？_木棉软糖的博客-CSDN博客](https://blog.csdn.net/ZULJ131/article/details/123016709)
4. [@Autowired 报错的 4 种情况！_Java技术栈的博客-CSDN博客](https://blog.csdn.net/youanyyou/article/details/118687325)
5. [spring-boot中的auto-configuration和configuration的区别 - 简书 (jianshu.com)](https://www.jianshu.com/p/4fc8cfa792c3)
6. [为什么 Spring和IDEA 都不推荐使用 @Autowired 注解 (qq.com)](https://mp.weixin.qq.com/s/TXOIjoBqCrWBEPCVPrJFnw)

#### 自定义SDK包中for循环拼接字符串

[JAVA拼接字符串用+号和append的区别_append和加号的区别_小笨狗的小胖纸的博客-CSDN博客](https://blog.csdn.net/m0_37590468/article/details/80941862)

[StringBuffer和StringBuilder区别详解（Java面试）_简述stringbuffer和stringbuilder有什么区别_辰兮要努力的博客-CSDN博客](https://blog.csdn.net/weixin_45393094/article/details/104526603)

#### SDK里非主要不相关配置的传参

[java可变形参的使用_java可变形参字符连接_K＆D的博客-CSDN博客](https://blog.csdn.net/qq_51694024/article/details/110391656)

### 对比用户认证(会话跟踪)不同方式

[用户认证：基于jwt和session的区别和优缺点 - 掘金 (juejin.cn)](https://juejin.cn/post/6844903856942350349)

### 编译器运行期和类加载生命周期的关系

[深入理解JVM（十七）一一 类的生命周期详解 - 掘金 (juejin.cn)](https://juejin.cn/post/7010590579553730568)

[java编译期、运行期_java代码什么时候编译_赶路人儿的博客-CSDN博客](https://blog.csdn.net/liuxiao723846/article/details/104327356)

### 前端不同页面传参

1. [Vue-路由传递query参数两种方式 - 掘金 (juejin.cn)](https://juejin.cn/post/7240600121208029239)
2. [路由传参的三种方式（query/params）_params传参_么心么肺的博客-CSDN博客](https://blog.csdn.net/weixin_41545048/article/details/99448820)
3. [Vue路由传参详解（params 与 query）_vue params传参_coder_7的博客-CSDN博客](https://blog.csdn.net/m0_46217225/article/details/119808510?utm_medium=distribute.pc_relevant.none-task-blog-2~default~baidujs_baidulandingword~default-0-119808510-blog-99448820.235^v38^pc_relevant_sort_base1&spm=1001.2101.3001.4242.1&utm_relevant_index=1)
4. [vue3 router.push 传参路由跳转错误提示 Argument type {xxx} is not assignable to parameter type RouteLocationRaw_userouter().push报错_落杉丶的博客-CSDN博客](https://blog.csdn.net/qq_46554590/article/details/127715203)
5. params和query传参的区别：[query传参和params传参的区别_nest@get query和params传参区别_方快樂的博客-CSDN博客](https://blog.csdn.net/qq_43987917/article/details/120403046)

### 远程连接

####   1、安装cloudflared  client客户端服务

将 下载好的可执行文件`(cloudflared-windows-amd64.exe)` 复制到 自己定义的目录 并改短名称为`(cloudflared.exe)`，方便操作

添加touket

1. 报错：

   > 2023-09-17T07:28:57Z INF Installing cloudflared Windows service
   > cloudflared service is already installed at Cloudflared; if you are running a cloudflared tunnel, you can point it to multiple origins, avoiding the need to run more than one cloudflared service in the same machine; otherwise if you are really sure, you can do `cloudflared service uninstall` to clean up the existing service and then try again this command

   或报错：

   > Cannot establish a connection to the service control manager: Access is denied

   就先`cloudflared service uninstall`，然后在进行安装cloudflared  client客户端服务。

2. ```
     # 你的freenom二级域名
     #- hostname: kaopao.chenkai.fun
     #  service: http://localhost:5173
     # 你的freenom二级域名
     #- hostname: rdp.chenkai.fun
     #  service: http://localhost:3000
   ```

   

> 配置:
>
> 1. [CloudFlare Argo Tunnel配置 - 实现内网穿透 - 码农教程 (manongjc.com)](http://www.manongjc.com/detail/62-eflvbzhmmvhjzae.html)
> 2. [使用cloudflare tunnel免费内网穿透，实现网站的外网访问和远程桌面 - 知乎 (zhihu.com)](https://zhuanlan.zhihu.com/p/621870045)
> 3. [如何使用Cloudflare配置rdp穿透 - 知乎 (zhihu.com)](https://zhuanlan.zhihu.com/p/655722503)
> 4. [cloudflared内网穿透实现Windows远程桌面 | 娃娃Code (dollcode.cn)](https://blog.dollcode.cn/cloudflared-tunnel-rdp)
> 5. [Releases · cloudflare/cloudflared (github.com)](https://github.com/cloudflare/cloudflared/releases)
> 6. [未备案域名使用Cloudflare设置域名URL转发-腾讯云开发者社区-腾讯云 (tencent.com)](https://cloud.tencent.com/developer/article/2151946)
> 7. [CloudFlare Workers 设置使用自定义域名_cloudflare 添加自定义域_一曲横笛的博客-CSDN博客](https://blog.csdn.net/m0_58606834/article/details/124670218)
> 8. [Freenom申请免费域名_怎么申请freenom免费域名_一曲横笛的博客-CSDN博客](https://blog.csdn.net/m0_58606834/article/details/124493114)
> 9. [Tunnels - Cloudflare Zero Trust](https://one.dash.cloudflare.com/c8de9c29de95f7db168bde92628d7e5d/access/tunnels)
>
> 补充:
>
> 1. 补充可以用来更新或删除客户端服务里的令牌指令：[在 Windows 系统中删除「服务」的 4 种方法 - 系统极客 (sysgeek.cn)](https://www.sysgeek.cn/windows-delete-service/)
> 2. 虚拟机传文件：[如何往虚拟机内传文件的3种方法 - 淳_风u云 - 博客园 (cnblogs.com)](https://www.cnblogs.com/chun-xiaolin001/p/10285377.html)
> 3. [VMware虚拟机网速过慢解决办法_虚拟机网速慢怎么解决_NoloseWind的博客-CSDN博客](https://blog.csdn.net/WindNolose/article/details/122769605)
> 4. 远程桌面连接出现了内部错怎么办？（远程连接内部错误的处理）：[远程桌面连接出现了内部错误怎么解决？（4种方法） (anyviewer.cn)](https://www.anyviewer.cn/how-to/remote-desktop-an-internal-error-has-occurred-6540.html)
> 5. 查找用户：[WIN10远程连接的计算机名和用户名填什么_远程连接这个名字是什么名字_huayang183的博客-CSDN博客](https://blog.csdn.net/qq_18671415/article/details/118068633)
> 6. 查看query命令是否存在：[win10中query用不了是为什么？_其他-CSDN问答](https://ask.csdn.net/questions/7409661)
> 7. [Win系统远程桌面连接教程/查询用户名和密码_远程桌面连接用户名是什么_不羁的程序员~的博客-CSDN博客](https://blog.csdn.net/qq_55172460/article/details/123664952)
> 8. [远程计算机名称和用户名是什么,Windons系统如何修改远程登录用户名_Ssiya的博客-CSDN博客](https://blog.csdn.net/weixin_30607173/article/details/117954410?spm=1001.2101.3001.6650.7&utm_medium=distribute.pc_relevant.none-task-blog-2~default~BlogCommendFromBaidu~Rate-7-117954410-blog-123664952.235^v38^pc_relevant_sort_base1&depth_1-utm_source=distribute.pc_relevant.none-task-blog-2~default~BlogCommendFromBaidu~Rate-7-117954410-blog-123664952.235^v38^pc_relevant_sort_base1&utm_relevant_index=13)
> 9. [win10系统，找不到gpedit.msc文件怎么办？组策略编辑器添加方法 - 知乎 (zhihu.com)](https://zhuanlan.zhihu.com/p/381084692)
> 10. [连不上远程桌面，一直处于正在配置远程会话的状态，可能是限制了连接数量 - 夏目❤小司 - 博客园 (cnblogs.com)](https://www.cnblogs.com/shaojs/p/11319854.html)
> 11. 一直处于正在配置连接的其他办法：[win10开启远程桌面连接的的一波三折——无法连接到远程计算机、你的凭据不工作_未启用对服务器的远程访问_独孤尚良dugushangliang的博客-CSDN博客](https://blog.csdn.net/dugushangliang/article/details/97619059)
> 12. 一直处于正在配置连接的较好的解决办法：[远程桌面由于以下原因之一无法连接到远程计算机,富含多种解决方案，全网最详细_网络架构师0001的博客-CSDN博客](https://blog.csdn.net/qq_45848361/article/details/113878113)

### 序列化

[Dog.java](file://‪E:\学习\Java学习\韩顺平 2021零基础学Java 【软件 资料 代码 笔记】\代码\chapter19\src\com\hspedu\outputstream_\Dog.java)

### MySQL缓存池和连接池

radis缓存这里，我是想存储总用户数量，我也有点想存储全部用户，但是不现实，也没必要，所以想存储**不同用户的匹配用户的第一份数据**，还可以**随机存几份首页推荐的数据**，减小首页访问量大的问题，**标签选择这块的数据**，也可以适当考虑用Redis存储

1. 是否要用Redis：
   1. [使用redis作为缓存，数据还需要存入数据库中吗？（转） - 北回归线的喵 - 博客园 (cnblogs.com)](https://www.cnblogs.com/ffaiss/p/10981949.html#:~:text=1redis只是缓存，不是数据库如mysql，所以redis中有的数据库，mysql中一定有。,2用户请求先去请求redis，如果没有，再去数据库中去读取。 3redis中缓存一些请求量比较大的数据（这些缓存数据，mysql中一定也是有的），没必要所有数据都缓存到redis中。)
   2. [mysql有缓存 为什么还要用redis,为什么需要使用redis缓存_周楷雯的博客-CSDN博客](https://blog.csdn.net/weixin_42659196/article/details/115926725)
2. MySQL缓存是什么：[MySQL缓存深入理解（全网最深、最全、最实用）_mysql缓存表-CSDN博客](https://blog.csdn.net/Bb15070047748/article/details/106489254)
   1. [什么是MySQL数据库的缓存池原理？看完或许就懂了 - 知乎 (zhihu.com)](https://zhuanlan.zhihu.com/p/343464560)
   2. [全方位带你了解MySQL的缓冲池（Buffer Pool） - 掘金 (juejin.cn)](https://juejin.cn/post/7064855214158774285)
3. 缓存池在哪里：[什么是MySQL数据库的缓存池原理？看完或许就懂了 - 知乎 (zhihu.com)](https://zhuanlan.zhihu.com/p/343464560)
4. 连接池又是什么：
   1. [JDBC连接数据库的七个步骤（超详细）-CSDN博客](https://blog.csdn.net/weixin_43520450/article/details/107230205)
   2. [MySql数据库连接池专题 - aspirant - 博客园 (cnblogs.com)](https://www.cnblogs.com/aspirant/p/6747238.html)
5. 他们有关系么？

### java8

[stream流中map和foreach的使用与区别 - 掘金 (juejin.cn)](https://juejin.cn/post/7034504770647752718)

[Java中“::”的含义和用法_zxn0911的博客-CSDN博客](https://blog.csdn.net/qq_46249770/article/details/123805088?utm_medium=distribute.pc_relevant.none-task-blog-2~default~baidujs_baidulandingword~default-0-123805088-blog-87798829.235^v38^pc_relevant_sort_base1&spm=1001.2101.3001.4242.1&utm_relevant_index=3)

### vue

[vue中组件的props属性（详）_vue props_suoh's Blog的博客-CSDN博客](https://blog.csdn.net/qq_41579104/article/details/120997444)

### 定时任务:

[@Scheduled定时任务的使用_scheduled每五秒钟执行一次-CSDN博客](https://blog.csdn.net/ITKidKid/article/details/126386738?ops_request_misc=%7B%22request%5Fid%22%3A%22167031326516800180696966%22%2C%22scm%22%3A%2220140713.130102334.pc%5Fall.%22%7D&request_id=167031326516800180696966&biz_id=0&utm_medium=distribute.pc_search_result.none-task-blog-2~all~first_rank_ecpm_v1~times_rank-1-126386738-null-null.142^v67^control,201^v4^add_ask,213^v2^t3_control2&utm_term=%40Scheduled&spm=1018.2226.3001.4187)

### picgo图床:

1. [使用 jsDelivr CDN 加速 Github 仓库的图片，以作为博客的图床_cdn图床手机-CSDN博客](https://blog.csdn.net/CQG1988/article/details/101652805#:~:text=整个过程比较简单，创建 Github 仓库，并获取 token，填入 PicGo 配置即可完成。 使用 jsDelivr,Github 存储图片，利于博主对于图片的掌控。 使用 PicGo 的原因是因为能够方便地将上传图片到 Github，并直接获取 jsDelivr 的加速后的图片地址。)
2. [在PicGo上使用github图床解决typora上传csdn图片不显示问题（保姆级教程）_Xpccccc的博客-CSDN博客](https://blog.csdn.net/qq_44121078/article/details/133612506)
3. [使用Github+picGo搭建图床，保姆级教程来了 - 知乎 (zhihu.com)](https://zhuanlan.zhihu.com/p/489236769)
4. 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

### 算法

[详解编辑距离算法-Levenshtein Distance_BoCong-Deng的博客-CSDN博客](https://blog.csdn.net/DBC_121/article/details/104198838)

### java基础笔记

[java笔记01.pdf](file://E:/学习/Java学习/java_hsp视频笔记/java笔记01.pdf)

[java笔记02.pdf](file://E:/学习/Java学习/java_hsp视频笔记/java笔记02.pdf)

[java笔记03.pdf](file://E:/学习/Java学习/java_hsp视频笔记/java笔记03.pdf)

### 补充

项目结构示例:

![image-20230922170618878](https://gitee.com/chenkai0101/imags/raw/master/imgs/202309221706134.png)

1. [ TyporaChina官方使用教程](https://typorachina.com/guide/how-tos/customize-list-styles.html)

2. [设置鼠标右键文件夹打开idea_右键打开idea_我的世界因你而完美的博客-CSDN博客](https://blog.csdn.net/qq_45155480/article/details/121203173)

3. [idea-快捷键设置（代码格式化）_AlbenXie的博客-CSDN博客](https://blog.csdn.net/AlbenXie/article/details/99727636)

4. [IDEA设置单行行首注释去掉多余空格-腾讯云开发者社区-腾讯云 (tencent.com)](https://cloud.tencent.com/developer/article/1798240)

5. [Mybatis之map-underscore-to-camel-case开启驼峰功能_map-underscore-to-camel-case:true_春风化作秋雨的博客-CSDN博客](https://blog.csdn.net/jiahao1186/article/details/113044099)

6. [idea中设置选中变量（包括其他相同值）高亮颜色_idea中变量提示颜色_我吃西红柿11的博客-CSDN博客](https://blog.csdn.net/qq_21223653/article/details/106327036)

7. [Java中的序列化与反序列化——transient（二） - 知乎 (zhihu.com)](https://zhuanlan.zhihu.com/p/625278581)

8. [什么是渐进式框架？ - 知乎 (zhihu.com)](https://zhuanlan.zhihu.com/p/140378027)

9. [数据逻辑删除和物理删除的理解_逻辑删除的好处_秀发浓密的博客-CSDN博客](https://blog.csdn.net/king007c/article/details/86641738)

10. [【js】JS数组复制或克隆新数组修改不影响原数组_js复制数组,原数组不变-CSDN博客](https://blog.csdn.net/Mrerlou/article/details/120306960)

11. [(2 封私信 / 21 条消息) 网页头部的声明应该是用 lang="zh" 还是 lang="zh-cn"？ - 知乎 (zhihu.com)](https://www.zhihu.com/question/20797118)



![image-20230915222756042](https://gitee.com/chenkai0101/imags/raw/master/imgs/202309152227126.png)

[Sunny-Ngrok实现自定义域名内网穿透 - 简书 (jianshu.com)](https://www.jianshu.com/p/6d119658a8b3)

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

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

# 网页技巧

解除复制权限问题，小书签实测对飞书有效：[【总结】解除网页文本禁止复制限制的六种方法 - 知乎 (zhihu.com)](https://zhuanlan.zhihu.com/p/370708102)
