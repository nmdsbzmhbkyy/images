单体项目改微服务，需要再单体项目的基础上，新建一个项目。

# ○改造为微服务的目的

当某个服务挂了，其他微服务不会挂。专注于提供某类特定功能的代码，而不是把所有的代码全部放到同一个项目里。会把整个大的项目按照一定的功能、逻辑进行拆分，拆分为多个子模块，每个子模块可以独立运行、独立负责一类功能，子模块之间相互调用、互不影响。

**微服务的几个重要的实现因素**：服务拆分、服务调用、服务管理。

# ○微服务的部分概念

## 1、微服务实现技术？

- Spring Cloud
- **Spring Cloud Alibaba**（以此为例）
- Dubbo（DubboX）
- RPC（GRPC、TRPC）

本质上都是通过 HTTP、或者其他的网络协议进行通讯来实现的，所以没有上面的组件，实际上也可以实现微服务。补充参考：[SpringCloud 入门实战基础篇 - 知乎 (zhihu.com)](https://zhuanlan.zhihu.com/p/608109979)

## 2、Spring Cloud Alibaba

- 官网：https://github.com/alibaba/spring-cloud-alibaba
- 中文文档：https://sca.aliyun.com/zh-cn/
- 本质：是在 Spring Cloud 的基础上，进行了增强，补充了一些额外的能力，根据阿里多年的业务沉淀做了一些定制化的开发
- 注意！一定要选择相对应的版本：https://sca.aliyun.com/zh-cn/docs/2021.0.5.0/overview/version-explain
- springcloud alibaba介绍:

![img](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311220200528.png)

1. Spring Cloud Gateway：网关
2. Nacos：服务注册和配置中心（集中存管项目中所有服务的信息，便于服务之间找到彼此；同时，还支持集中存储整个项目中的配置。） 
3. Sentinel：熔断限流 
4. Seata：分布式事务 
5. RocketMQ：消息队列，削峰填谷 
6. Docker：使用Docker进行容器化部署 
7. Kubernetes：使用k8s进行容器化部署

- 整个微服务请求流程：

![img](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311220205105.png)

- 补充：另一个分布式微服务框架 https://github.com/Nepxion/Discovery

# 1、改造前思考

## 1）改造分布式？

从业务需求出发，思考是否有单机的要改为分布式的，如用户登录功能可以改造为分布式登录。
其他内容：

- 有没有用到单机的锁？改造为分布式锁（redission）
- 有么有用到本地缓存？改造为分布式缓存（Redis）
- 需不需要用到分布式事务？比如操作多个库

## 2）微服务划分

从业务出发，想一下哪些功能 / 职责是一起的？即有哪些功能模块？

大致可以划分为：依赖服务、公共模块、业务功能。示例如下：

> 1. 依赖服务：
>
>    - 注册中心：Nacos
>
>    - 微服务网关（kaooj-backend-gateway）：Gateway 聚合所有的接口，统一接受处理前端的请求
>
> 1. 公共模块：
>
>    - common 公共模块（kaooj-backend-common）：全局异常处理器、请求响应封装类、公用的工具类等
>
>    - model 模型模块（kaooj-backend-model）：很多服务公用的实体类
>
>    - 公用接口模块（kaooj-backend-service-client）：只存放接口，不存放实现（多个服务之间要共享）
>
> 1. 业务功能：
>
>
>    - 用户服务（kaooj-backend-user-service：8102 端口）：
>      - 注册（后端已实现）
>      - 登录（后端已实现，前端已实现）
>      - 用户管理
>    - aaa服务（kaooj-backend-aaa-service：8103）
>      - 创建aaa（管理员）
>      - 删除aaa（管理员）
>      - 修改aaa（管理员）
>      - 搜索aaa（用户）
>      - ......
>
>
>    - bbb服务（kaooj-backend-bbb-service，8104 端口，较重的操作）
>      - 执行bbb
>      - ......
>

另外，某些系统的部分服务本身就是独立的，如沙箱服务。因此可以不用纳入 Spring Cloud 的管理。

## 3）路由划分

这里以上面的微服务划分中的业务服务来进行路由划分。另外，这步是为了项目的内部调用，因为有点接口要对其做权限控制，不能直接给任何人来调用。

这里在 springboot 的配置文件中的 context-path 统一修改各项目的接口前缀，如：

> - /api/user
> - /api/aaa
> - /api/bbb

另外，服务提供商还需要暴露其内部服务，如：

> - 用户服务：
>   - /api/user
>   - /api/user/inner（内部调用，网关层面要做限制）
> - aaa服务：
>   - /api/aaa
>   - /api/aaa/inner（内部调用，网关层面要做限制）
> - bbb服务：
>   - /api/bbb
>   - /api/bbb/inner（内部调用，网关层面要做限制）



# 2、新建工程 

Spring Cloud 有相当多的依赖，参差不齐，不建议随意找一套配置、或者自己写。

建议用官方提供的脚手架创建项目：https://start.aliyun.com/

- 给项目增加全局依赖配置文件。

- 创建完初始项目后，补充 Spring Cloud 依赖（这里选择2021.0.5版本，即Nacos 应该是2.2.0版本）：

```xml
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-dependencies</artifactId>
    <version>2021.0.5</version>
    <type>pom</type>
    <scope>import</scope>
</dependency>
```

- 绑定子父依赖关系：依次使用 new modules 和 spring boot Initializr 创建各模块，需要给各模块之间绑定子父依赖关系，将前面的微服务划分的“微服务网关、公共模块、业务模块”作为新建项目的子依赖。（目的：父模块定义 modules，子模块引入 parent 语法，可以通过继承父模块配置，统一项目的定义和版本号。）

#  3、同步代码和依赖

1）common 公共模块（kaooj-backend-common）：全局异常处理器、请求响应封装类、公用的工具类、公共包等。

2）model 模型模块（kaooj-backend-model）：很多服务公用的实体类
直接复制 model 包。

3）公用接口模块（kaooj-backend-service-client）：只存放接口，不存放实现（多个服务之间要共享），即注册中心nacos会在这里去查找对应的服务模块。暂时先无脑搬运所有的 service。另外，需要指定 openfeign（客户端调用工具）的版本，用来配置不同的feignclient类：

```xml
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-starter-openfeign</artifactId>
    <version>3.1.5</version>
</dependency>
```

4）具体业务服务实现
给所有业务服务引入公共依赖：

```xml
<dependency>
    <groupId>com.kaomao</groupId>
    <artifactId>kaooj-backend-common</artifactId>
    <version>0.0.1-SNAPSHOT</version>
</dependency>
<dependency>
    <groupId>com.kaomao</groupId>
    <artifactId>kaooj-backend-model</artifactId>
    <version>0.0.1-SNAPSHOT</version>
</dependency>
<dependency>
    <groupId>com.kaomao</groupId>
    <artifactId>kaooj-backend-service-client</artifactId>
    <version>0.0.1-SNAPSHOT</version>
</dependency>
```

各个主类引入注解，即引入 application.yml 配置。

# 4、实现服务内部调用

- 现在的问题是，某个服务依赖用户服务，但是代码已经分到不同的包，找不到对应的 Bean。因此可以使用 Open Feign 组件实现跨服务的远程调用。

- Open Feign：Http 调用客户端，提供了更方便的方式来让你远程调用其他服务，不用关心服务的调用地址
- Nacos 注册中心：取服务调用地址

1. 梳理服务的调用关系，确定哪些服务（接口）需要给内部调用

   > - 用户服务：没有其他的依赖
   >
   > - aaa服务：
   >   userService.getById(userId)
   >   userService.getUserVO(user)
   >   userService.listByIds(userIdSet)
   >   userService.isAdmin(loginUser)
   >   userService.getLoginUser(request)
   >   bbbService.doJudge(questionSubmitId)
   >
   > - 判题服务：
   >    aaa.getById(questionId)
   >    aaa.getById(questionSubmitId)
   >    aaa.updateById(questionSubmitUpdate)
   >
2. 确认要提供哪些服务

   > - 用户服务：没有其他的依赖
   >   userService.getById(userId)
   >   userService.getUserVO(user)
   >   userService.listByIds(userIdSet)
   >   userService.isAdmin(loginUser)
   >   userService.getLoginUser(request)
   >
   > - aaa服务：
   >   aaa.getById(questionId)
   >   aaa.getById(questionSubmitId)
   >   aaa.updateById(questionSubmitUpdate)
   >
   > - bbb服务：
   >   bbb.doJudge(questionSubmitId)

3. 实现 client 接口：

   > - 对于用户服务，有一些不利于远程调用参数传递、或者实现起来非常简单（工具类），可以直接用默认方法，无需远程调用，节约性能
   >
   >
   > - 开启 openfeign 的支持，把我们的接口暴露出去（服务注册到注册中心上），作为 API 给其他服务调用（其他服务从注册中心寻找）
   >
   >
   > - 需要修改每个服务提供者的 context-path 全局请求路径
4. 修改各业务服务的调用代码为 feignClient
5. 编写 feignClient 服务的实现类，注意要和之前定义的客户端保持一致
6. Nacos 注册中心启动 

   一定要选择和springcloud alibaba对应的版本

   - 教程：https://sca.aliyun.com/zh-cn/docs/2021.0.5.0/user-guide/nacos/overview
   - Nacos 官网教程：https://nacos.io/zh-cn/docs/quick-start.html
   - 官网下载 Nacos：https://github.com/alibaba/nacos/releases/tag/2.2.0

   安装好后，进入其 bin 目录启动：

   ```shell
   startup.cmd -m standalone
   ```

7. 开启 Nacos 的配置，让服务之间能够互相发现
   所有模块引入 Nacos 依赖，然后给业务服务（包括网关）增加配置：
```yml
spring:
    cloud:
        nacos:
          discovery:
            server-addr: 127.0.0.1:8848  
```
8. 给业务服务项目启动类打上注解，开启服务发现、找到对应的客户端 Bean 的位置：
```java
@EnableDiscoveryClient
@EnableFeignClients(basePackages = {"com.kaomao.kaoojbackendserviceclient.service"})
```

9. 全局引入负载均衡器依赖：
```xml
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-loadbalancer</artifactId>
    <version>3.1.5</version>
</dependency>
```

10. 启动项目，测试依赖能否注入，能否完成相互调用(通过网页输入对应的api或通过knife4j来调试，目的是为了测试是否实现那服务的内部调用)

**补充：**

1. 服务提供者：理解为接口的实现类，实际提供服务的模块（服务注册到注册中心上）
2. 服务消费者：理解为接口的调用方，需要去找到服务提供者，然后调用。（其他服务从注册中心寻找）

**注意事项：**

1. 要给接口的每个方法打上请求注解，注意区分 Get、Post
2. 要给请求参数打上注解，比如 RequestParam、RequestBody
3. FeignClient 定义的请求路径一定要和服务提供方实际的请求路径保持一致

# 5、微服务网关

微服务网关（yuoj-backend-gateway）：Gateway 聚合所有的接口，统一接受处理前端的请求，否则前端请求不同服务要请求不同端口，比较麻烦，不便于修改。
目的：

- 所有的服务端口不同，增大了前端调用成本
- 所有服务是分散的，你可需要集中进行管理、操作，比如集中解决跨域、鉴权、接口文档、服务的路由、接口安全性、流量染色、限流

Gateway 是应用层网关：会有一定的业务逻辑（比如根据用户信息判断权限），想自定义一些功能，需要对这个技术有比较深的理解。
Nginx 是接入层网关：比如每个请求的日志，通常没有业务逻辑。




```
.notion-list-disc > ul:before {
    content: '';
    height: calc(100% - 0px);
    width: 8px;
    background-color: rgba(0,0,0,0.2);
    position: absolute;
    left: -17px;
    top: 0px;
    -webkit-transform: scaleX(.25);
    transform: scaleX(.25);
    display: block;
}
.notion-list-disc {
    list-style-type: disc;
    -webkit-padding-start: 1.4em;
    padding-inline-start: 1.4em;
    margin-top: 0;
    margin-bottom: 0;
    position: relative;
}
.notion-list-numbered > ol:before {
    content: '';
    height: calc(100% - 0px);
    width: 8px;
    background-color: rgba(0,0,0,0.2);
    position: absolute;
    left: -21px;
    top: 0px;
    -webkit-transform: scaleX(.25);
    transform: scaleX(.25);
    display: block;
}
.notion-quote {
display: block;
border-radius: 5px;
border-color: #55e294;
border-left-color: #1fc368;
background-color: var(--notion-green_background_co);
width: 100%;
```