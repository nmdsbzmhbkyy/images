# Docker的安装并使用，及java对其的操作

# ○docker的简单应用:

-   用于实现程序和宿主机的隔离：&#x20;

    为了进一步提升系统的安全性，把不同的程序和宿主机进行隔离，使得某个程序（应用）的执行不会影响到系统本身

    可以理解为对一系列应用程序、服务和环境的封装，从而把程序运行在一个隔离的、密闭的、隐私的空间内，对外整体提供服务。 &#x20;

    可以把一个容器理解为一个新的电脑（定制化的操作系统）。
-   用于部署前后端：

    🦥 大公司绝大多数的项目都是用容器。它有一个好处，docker镜像可以将整个项目的环境，以及项目的代码，本来是要手动安装软件、上传代码，现在可以把这些软件和代码全部封装到一个镜像里面，就像我们装操作系统一样。
    之后如果需要启动这个项目，直接启动这个镜像，把这镜像拿来运行一下就好了，不需要去反复执行命令去安装了。
    🪔 docker 是容器，可以将项目的环境（比如 java、nginx）和项目的代码一起打包成镜像，所有人都能下载镜像，更容易分发和移植。再启动项目时，不需要敲一大堆命令，而是直接下载镜像、启动镜像就可以了。
    docker 可以理解为软件安装包。

# ○Docker 基本概念

镜像：用来创建容器的安装包，可以理解为给电脑安装操作系统的系统镜像 &#x20;
容器：通过镜像来创建的一套运行环境，一个容器里可以运行多个程序，可以理解为一个电脑实例 &#x20;
Dockerfile：制作镜像的文件，可以理解为制作镜像的一个清单 &#x20;

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172246391.png)

镜像仓库：存放镜像的仓库，用户可以从仓库下载现成的镜像，也可以把做好的镜像放到仓库里 &#x20;

推荐使用 docker 官方的镜像仓库：[https://hub.docker.com/search?q=nginx](https://hub.docker.com/search?q=nginx "https://hub.docker.com/search?q=nginx")

# ○Docker 能实现哪些资源的隔离？ &#x20;

-   看图理解： &#x20;

    ![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172246630.png)

    1）Docker 运行在 Linux 内核上 &#x20;

    2）CGroups：实现了容器的资源隔离，底层是 Linux Cgroup 命令，能够控制进程使用的资源 &#x20;

    3）Network 网络：实现容器的网络隔离，docker 容器内部的网络互不影响 &#x20;

    4）Namespaces 命名空间：可以把进程隔离在不同的命名空间下，每个容器他都可以有自己的命名空间，不同的命名空间下的进程互不影响。 &#x20;

    5）Storage 存储空间：容器内的文件是相互隔离的，也可以去使用宿主机的文件 &#x20;

docker compose：是一种同时启动多个容器的集群操作工具（容器管理工具），一般情况下，了解即可，实际使用 docker compose 时去百度配置文件 &#x20;

# 1、准备linux服务器

可以购买服务商的，but要米，所以可以选择安装虚拟机软件来配置linux服务区。

> 1、一般情况下，不建议在 Windows 系统上安装，Windows 本身就自带了一个虚拟机叫 WSL，但是VMware是一个更专业的、隔离的虚拟机软件。 &#x20;
> 2、此处虚拟机软件使用VMware Workstation，参考链接：[VMware虚拟机安装及使用教程/解决Win10玩游戏卡顿、win7及win10激活工具](https://www.bilibili.com/video/av47094959/?vd_source=b6865a5e968b98ea450a39e00ef7e85d "VMware虚拟机安装及使用教程/解决Win10玩游戏卡顿、win7及win10激活工具")
> 3、也可以使用免费的 VMWare Workstation Player 软件：[https://www.vmware.com/cn/products/workstation-player.html](https://www.vmware.com/cn/products/workstation-player.html "https://www.vmware.com/cn/products/workstation-player.html") &#x20;
> 4、安装 Linux 虚拟机、Docker 环境和远程开发环境，参考链接：[保姆级 Linux 远程开发教程](https://www.bilibili.com/video/BV1h94y1k7Jf/ )

选择ubuntu-linux发行版之一，ubuntu官网下载稳定版的桌面版后（[Ubuntu稳定版](https://www.releases.ubuntu.com/bionic/ "Ubuntu稳定版") 系统），在VMware新建虚拟机：

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224273.png)

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224279.png)

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224280.png)

选择自定义硬件：

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224281.png)

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224282.png)

# 2、ubuntu命令行安装docker软件

可以在ubuntu应用商店安装，也可以用命令行安装软件，但是ubuntu商店没有docker软件。

ctrl+alt+t打开命令行输入`sudo apt install docker.io`

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224283.png)

ctrl + L清屏，查看版本：

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224284.png)

执行docker run xxx：当发现没有对应镜像的时候，就会远程拉取对应镜像并输出一句xxx from docker，同时也表示docker安装成功。

# 3、远程开发准备

这里选择远程开发java程序，主要是使用远程开发直接在win电脑上操作linux服务器，这样就和之前在win上开发方式保持一致（tudo:啥,有什么区别么，还有前面的安装docker和win上配置有区别么?）,这里需要做一些准备工作:

-   首先需要可以在win中ping通；另外因为连接还依赖ssh协议，所以还需要再linux服务器内提供ssh连接的服务，即安装ssh服务器；因为是远程开发java环境，所以还需要安装基本的java环境，另外，因为开发的是springboot的web项目，所以还需要安装maven依赖管理工具（sprinboot项目就是用maven来启动项目）：
    1. 获取ip地址，实现网络连接，即win可以访问linux服务器，输入ifconfig查看ip（192.168.65.129），也可以在Ubuntu网络中查看。
    ![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224285.png)
    1. 输入命令`sudo apt install openssh-server`，安装ssh服务器:
        ![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224286.png)
    1. ubuntu中查看ssh服务是否开启（要是没开启的话用systemctl start sshd  ）：
       ![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224288.png)
    1. 更新本地的软件包的安装信息`sudo apt update`，然后安装java8的jdk`sudo apt install openjdk-8-jdk`，安装maven
    

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224289.png)

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224290.png)

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224291.png)

#  4、命令行操作 Docker 

1）查看命令用法

```shell
docker --help
```

查看具体子命令的用法：

```shell
docker run --help
```

2）从远程仓库拉取现成的镜像

用法：

```shell
docker pull [OPTIONS] NAME[:TAG|@DIGEST]
```

示例：

```shell
docker pull hello-world
```

3）根据镜像创建容器实例：

```shell
docker create [OPTIONS] IMAGE [COMMAND] [ARG...]
```

启动实例，得到容器实例 containerId：

```shell
sudo docker create hello-world
```

4）看容器状态：

```shell
sudo docker ps -a
```

5）启动容器：

```shell
docker start [OPTIONS] CONTAINER [CONTAINER...]
```

启动示例：

```shell
sudo docker start mystifying_shamir
```

6）查看日志：

```shell
sudo docker logs mystifying_shamir
```

启动示例：

```shell
sudo docker logs mystifying_shamir
```

7）删除容器实例：

```shell
docker rm [OPTIONS] CONTAINER [CONTAINER...]
```

删除示例：

```shell
sudo docker rm mystifying_shamir
```

8）删除镜像：

```shell
docker rmi --help
```

示例，强制删除：

```shell
sudo docker rmi hello-world -f
```

9）其他：构建镜像（build）、推送镜像（push）、运行容器（run）、执行容器命令（exec）等

#  5、Java 操作 Docker 

## 前置准备 

使用 Docker-Java：https://github.com/docker-java/docker-java

官方入门：https://github.com/docker-java/docker-java/blob/main/docs/getting_started.md

先引入依赖：

```xml
<!-- https://mvnrepository.com/artifact/com.github.docker-java/docker-java -->
<dependency>
    <groupId>com.github.docker-java</groupId>
    <artifactId>docker-java</artifactId>
    <version>3.3.0</version>
</dependency>
<!-- https://mvnrepository.com/artifact/com.github.docker-java/docker-java-transport-httpclient5 -->
<dependency>
    <groupId>com.github.docker-java</groupId>
    <artifactId>docker-java-transport-httpclient5</artifactId>
    <version>3.3.0</version>
</dependency>
```

DockerClientConfig：用于定义初始化 DockerClient 的配置（类比 MySQL 的连接、线程数配置）
DockerHttpClient：用于向 Docker 守护进程（操作 Docker 的接口）发送请求的客户端，低层封装（不推荐使用），你要自己构建请求参数（简单地理解成 JDBC）
DockerClient（推荐）：才是真正和 Docker 守护进程交互的、最方便的 SDK，高层封装，对 DockerHttpClient 再进行了一层封装（理解成 MyBatis），提供了现成的增删改查

## 远程开发 

使用 IDEA Development 先上传代码到 Linux，然后使用 JetBrains 远程开发完全连接 Linux 实时开发。

如果无法启动程序，修改 settings 的compiler 配置：-Djdk.lang.Process.launchMechanism=vfork

![image.png](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311191620654.png)

如果启动失败：

1）增加权限

2）重启虚拟机！重启远程开发环境！重启程序！

## 常用操作 

1）拉取镜像：

```java
String image = "nginx:latest";
PullImageCmd pullImageCmd = dockerClient.pullImageCmd(image);
PullImageResultCallback pullImageResultCallback = new PullImageResultCallback() {
    @Override
    public void onNext(PullResponseItem item) {
        System.out.println("下载镜像：" + item.getStatus());
        super.onNext(item);
    }
};
pullImageCmd
        .exec(pullImageResultCallback)
        .awaitCompletion();
System.out.println("下载完成");
```

2）创建容器：

```java
CreateContainerCmd containerCmd = dockerClient.createContainerCmd(image);
CreateContainerResponse createContainerResponse = containerCmd
        .withCmd("echo", "Hello Docker")
        .exec();
System.out.println(createContainerResponse);
```

3）查看容器状态：

```java
ListContainersCmd listContainersCmd = dockerClient.listContainersCmd();
List<Container> containerList = listContainersCmd.withShowAll(true).exec();
for (Container container : containerList) {
    System.out.println(container);
}
```

4）启动容器：

```java
dockerClient.startContainerCmd(containerId).exec();
```

5）查看日志：

```java
// 查看日志

LogContainerResultCallback logContainerResultCallback = new LogContainerResultCallback() {
    @Override
    public void onNext(Frame item) {
        System.out.println(item.getStreamType());
        System.out.println("日志：" + new String(item.getPayload()));
        super.onNext(item);
    }
};
// 阻塞等待日志输出
dockerClient.logContainerCmd(containerId)
        .withStdErr(true)
        .withStdOut(true)
        .exec(logContainerResultCallback)
        .awaitCompletion();
```

6）删除容器：

```java
dockerClient.removeContainerCmd(containerId).withForce(true).exec();
```

7）删除镜像：

```java
dockerClient.removeImageCmd(image).exec();
```

# 补充：远程部署及使用docker参考

以下参考阿里云服务器ECS实验室

## 1、创建实验资源

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224292.png)

## 2、部署Docker

在ECS实例上部署Docker

说明：本实验使用的CentOS 8.5操作系统已经切换过CentOS 8源地址。如果在非本实验的CentOS 8操作系统环境中部署Docker时，需要手动切换CentOS 8源地址。具体操作，请参见[CentOS 8 EOL如何切换源？](https://help.aliyun.com/document_detail/405635.htm "CentOS 8 EOL如何切换源？")。

### 前置步骤：远程连接

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224293.png)

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224294.png)

### ①安装dnf。dnf是新一代的rpm软件包管理器。

说明：本实验环境中已安装过dnf，可忽略本步骤。

> yum -y install dnf

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224295.png)

### ②安装Docker存储驱动的依赖包。

说明：本实验环境中已安装过Docker存储驱动的依赖包，您可忽略本步骤。

> dnf install -y device-mapper-persistent-data lvm2

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224296.png)

### ③添加稳定的Docker软件源。

> dnf config-manager --add-repo=https\://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224297.png)

### ④查看已添加的Docker软件源。

> dnf list docker-ce

返回结果如下，可查看到已添加的Docker软件源。

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224298.png)

### ⑤安装docker-ce。

> dnf install -y docker-ce --nobest

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224299.png)

下载成功：

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224300.png)

### ⑥启动Docker服务。

> systemctl start docker

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224301.png)

### ⑦查看Docker服务的运行状态。

> systemctl status docker

返回结果如下，表示Docker服务处于运行中的状态。按q键退出查看Docker服务的运行状态。

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224302.png)

### ⑧查看Docker的版本。

> docker -v

返回结果如下，您可查看到Docker的版本。

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224303.png)

## 3、使用Docker

本步骤学会Docker的基本用法。

### ①管理Docker守护进程。

说明：通过yum源的方式安装的Docker（podman-docker）没有守护进程（systemd），因此不支持systemctl命令的相关操作。

#### 1.1运行Docker守护进程。

> systemctl start docker

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224304.png)

#### 1.2 停止Docker守护进程。

> systemctl stop docker

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224305.png)

#### 1.3 重启Docker守护进程。

> systemctl restart docker

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224306.png)

#### 1.4 设置Docker开机自启动。

> systemctl enable docker

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224307.png)

#### 1.5 查看Docker的运行状态。按q键退出查看Docker服务的运行状态。

> systemctl status docker

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224308.png)

### ②管理镜像。

#### 2.1 拉取镜像。本实验使用的是来自阿里云仓库的Apache镜像。

> docker pull registry.cn-hangzhou.aliyuncs.com/lxepoo/apache-php5

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224309.png)

下载成功：

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224310.png)

#### 2.2 修改标签。由于阿里云仓库镜像的镜像名称较长，可以修改镜像标签以便记忆区分。

> docker tag registry.cn-hangzhou.aliyuncs.com/lxepoo/apache-php5:latest aliweb:v1

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224311.png)

#### 2.3 查看已有镜像。

> docker images

返回结果如下，您可查看到两个镜像，一个是拉取的阿里云仓库的Apache镜像，另外一个是修改镜像标签后的镜像。

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224312.png)

#### 2.4 强制删除镜像。本实验中删除的镜像为拉取的阿里云仓库的Apache镜像。

> docker rmi -f registry.cn-hangzhou.aliyuncs.com/lxepoo/apache-php5

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224313.png)

### ③管理容器。

#### 3.1 执行如下命令，查看已有镜像。

> docker images

返回结果如下，可查看到修改镜像标签后的镜像的IMAGE ID。

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224315.png)

e121d5f99e1e

#### 3.2进入容器，其中您需要将命令中的IMAGE ID改为上一步中查询到的IMAGE ID。

> docker run -it IMAGE ID /bin/bash

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224316.png)

#### 3.3 输入exit，退出当前容器。

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224317.png)

#### 3.4 后台运行容器，其中您需要将命令中的IMAGE ID改为上一步中查询到的IMAGE ID。run命令加上–d参数可以在后台运行容器，--name指定容器命名为apache。

> docker run -d --name apache IMAGE ID

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224318.png)

#### 3.5 进入后台运行的容器。

> docker exec -it apache /bin/bash

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224319.png)

#### 3.6 输入exit，退出当前容器。

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224320.png)

#### 3.7 查看容器ID。

> docker ps

返回结果如下，您可查看到刚刚后台运行容器的容器ID（CONTAINER ID）。

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224321.png)

3195d5547751

#### 3.8 将容器做成镜像的命令为docker commit containerID/containerName repository:tag，该命令的参数说明：docker commit <容器ID或容器名> \[<仓库名>\[:<标签>]]。

在本实验中，执行如下命令，将容器做成镜像，其中您需要将命令中的CONTAINER ID改为上一步中查询到的CONTAINER ID。

> docker commit CONTAINER ID apachephp:v1

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224322.png)

#### 3.9 运行刚刚制作的镜像容器并将宿主机的8080端口映射到容器里去。

> docker run -d -p 8080:80 apachephp:v1

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224323.png)

#### 3.10 在您的本机浏览器中，打开新页签并访问http\://\<ECS弹性IP>:8080。

说明：

-   您需要将\<ECS弹性IP>替换为云产品列表中的ECS弹性IP。
-   ECS实例的安全组入方向规则需要放行8080端口。具体操作，请参见[添加安全组规则](https://help.aliyun.com/document_detail/25471.htm#concept-sm5-2wz-xdb "添加安全组规则")。本实验已为您开放ECS实例的安全组入方向规则的8080端口，您无需操作。

返回如下页面，说明容器运行成功。

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224324.png)

## 4、制作Docker镜像

本步骤指导您如何制作Docker镜像。

### ①准备Dockerfile内容。

#### 1.1 执行如下命令，新建并编辑Dockerfile文件。

> vim Dockerfile

#### 1.2 按i进入编辑模式，添加以下内容。

> \#声明基础镜像来源。
>
> FROM apachephp:v1
>
> \#声明镜像拥有者。
>
> MAINTAINER DTSTACK
>
> \#RUN后面接容器运行前需要执行的命令，由于Dockerfile文件不能超过127行，因此当命令较多时建议写到脚本中执行。
>
> RUN mkdir /dtstact
>
> \#开机启动命令，此处最后一个命令需要是可在前台持续执行的命令，否则容器后台运行时会因为命令执行完而退出。
>
> ENTRYPOINT ping www\.aliyun.com

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224325.png)

#### 1.3 按下键盘Esc键，输入:wq并按下enter键，保存并退出Dockerfile文件。

### ②构建镜像。

> docker build -t webalibabacloudlinux:v1 .    #命令末尾的.是Dockerfile文件的路径，不能忽略。
>
> docker images                                #查看是否创建成功。

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224326.png)

返回结果如下，表示已成功构建镜像。

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224327.png)

### ③运行容器并查看。

> docker run -d webalibabacloudlinux:v1    #后台运行容器。
>
> docker ps                                #查看当前运行中的容器。
>
> docker ps -a                             #查看所有容器，包括未运行中的。
>
> docker logs CONTAINER ID/IMAGE           #如未查看到刚才运行的容器，则用容器id或者名字查看启动日志排错。

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224328.png)

### ④制作镜像。

> docker commit CONTAINER ID dtstackweb:v1     #commit参数后添加容器ID和构建新镜像的名称和版本号。您需要将CONTAINER ID改为上一步查询到的IMAGE为webalibabacloudlinux:v1的CONTAINER ID。
>
> docker images                                #列出本地（已下载的和本地创建的）镜像。

返回结果如下，表示已成功制作镜像。

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311172224329.png)

### ⑤将镜像推送至远程仓库。

默认推送到Docker Hub。您需要先登录Docker，为镜像绑定标签，将镜像命名为Docker用户名/镜像名:标签的格式。最终完成推送。

说明：本步骤需要您有Docker Hub的账号，若没有可忽略本步骤。

> docker login --username=dtstack\_plus [registry.cn-shanghai.aliyuncs.com](http://registry.cn-shanghai.aliyuncs.com "registry.cn-shanghai.aliyuncs.com")    #执行后输入镜像仓库密码。
>
> docker tag \[ImageId] [registry.cn-shanghai.aliyuncs.com/dtstack123/test:\[标签\]](http://registry.cn-shanghai.aliyuncs.com/dtstack123/test:\[标签] "registry.cn-shanghai.aliyuncs.com/dtstack123/test:\[标签]")
>
> docker push [registry.cn-shanghai.aliyuncs.com](http://registry.cn-shanghai.aliyuncs.com "registry.cn-shanghai.aliyuncs.com")
