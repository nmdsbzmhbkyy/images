nas的应用：

1. [(持续更新)「NAS」小白必读，从入门到上手，保姆级干货分享。 (zhihu.com)](https://www.zhihu.com/tardis/zm/art/372594101?source_id=1005)
2. [【NAS】NAS还能这么用？（第一期）_哔哩哔哩_bilibili](https://www.bilibili.com/video/BV1VC4y1U7uk/?spm_id_from=333.1007.tianma.2-1-4.click&vd_source=b6865a5e968b98ea450a39e00ef7e85d)

CDN：

```
使用如下规则访问 CDN 资源：https://cdn.jsdelivr.net/gh/themusecatcher/resources@0.0.3/bao.jpg(https://cdn.jsdelivr.net/gh/<username>/<repo name>@<tag>/<resource name>)
⑥查看 CDN 资源目录：
https://cdn.jsdelivr.net/gh/themusecatcher/resources@0.0.3/
```

[使用jsDelivr和GitHub，上传本地静态资源到免费CDN_jsdelivr 上传_theMuseCatcher的博客-CSDN博客](https://blog.csdn.net/Dandrose/article/details/130552654)

[免费开源CDN jsDelivr使用-CSDN博客](https://blog.csdn.net/Mrlujiao_code/article/details/113309542?spm=1001.2101.3001.6650.3&utm_medium=distribute.pc_relevant.none-task-blog-2~default~BlogCommendFromBaidu~Rate-3-113309542-blog-130552654.235^v38^pc_relevant_sort_base1&depth_1-utm_source=distribute.pc_relevant.none-task-blog-2~default~BlogCommendFromBaidu~Rate-3-113309542-blog-130552654.235^v38^pc_relevant_sort_base1&utm_relevant_index=6)

代码高光样式css：

[prism代码高亮主题风格展示阁-腾讯云开发者社区-腾讯云 (tencent.com)](https://cloud.tencent.com/developer/article/1622399)

css样式工具:

- 样式: [Tailwind CSS](https://www.tailwindcss.cn/)
- 参考开源项目:[nmdsbzmhbkyy/NotionNext: 使用 NextJS + Notion API 实现的，支持多种部署方案的静态博客，无需服务器、零门槛搭建网站，为Notion和所有创作者设计。 (A static blog built with NextJS and Notion API, supporting multiple deployment options. No server required, zero threshold to set up a website. Designed for Notion and all creators.) (github.com)](https://github.com/nmdsbzmhbkyy/NotionNext)

# JDK8安装

[(136条消息) Java8与JDK1.8与JDK8与J2SE8与J2SE1.8的区别是什么？——Java的各个版本和各个版本的历史版本号的关系与解读_快乐李同学(李俊德-大连理工大学)的博客-CSDN博客](https://blog.csdn.net/wq6ylg08/article/details/91351339)

![img](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311261556762.png)

![img](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311261556883.png)

<img src="https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311261557366.png" alt="img"  />

## a、安装文件：

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311261556597.png)

## b、开发工具&源代码&公共jre（部分公共jre）安装：

这里有三个功能,都是有用的,更改一下位置直接下一步就可以了(更改一次后,另外两个功能的位置会一起修改),另外,这个公共jre可以不安装,但是最好还是安装上去,

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311261557870.png)

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311261557833.png)

## c、(额外)公共jre安装

这里提示还需要安装个公共jre,更换路径然后下一步(更换的路径要是空白的文件夹)

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311261557080.png)

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311261557144.png)

## d、配置JDK8：

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311261557962.png)

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311261557913.png)

删除一下原来的JDK11：

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311261557843.png)

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311261557168.png)

然后就出现了这个

![](https://cdn.jsdelivr.net/gh/nmdsbzmhbkyy/images@main/imgs/202311261557544.png)